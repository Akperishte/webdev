a  = int(input())

b = a+1

c = a-1

print ("The next number for the number",a,"is",b,end=".")

print ()

print("The previous number for the number",a,"is",c,end="."){}